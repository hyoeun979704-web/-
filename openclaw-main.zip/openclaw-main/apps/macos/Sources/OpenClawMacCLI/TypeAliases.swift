import OpenClawKit
import OpenClawProtocol

typealias ProtoAnyCodable = OpenClawProtocol.AnyCodable
typealias KitAnyCodable = OpenClawKit.AnyCodable
